package personnage.equipement ;

public class Arme {

    private String nom ;
    private int attaque ;

    public Arme( String nom, int attaque ) {
        this.set_nom( nom );        // Soit l'un
        this.attaque = attaque ;    // Soit l'autre, en fonction des cas
    }

    public Arme( Arme a ) {
        this( a.get_nom(), a.get_attaque() );
    }

    public Arme copy() {
        return new Arme( this );
    }

    public String get_nom() {
        return this.nom ;
    }

    public int get_attaque() {
        return this.attaque ;
    }

    public void set_nom( String value ) {
        this.nom = nom ;
    }

    public void set_attaque( int value ) {
        this.attaque = attaque ;
    }

}