package personnage.equipement ;

public class Armure {

    private String nom ;
    private int protection ;

    public Armure( String nom, int protection ) {
        this.nom = nom ;
        this.protection = protection ;
    }

    public Armure( Armure armure ) {
        this( armure.get_nom(), armure.get_protection() );
    }

    public String get_nom() {
        return this.nom ;
    }

    public int get_protection() {
        return this.protection ;
    }

    public void set_nom( String nouvelle_valeur ) {
        this.nom = nouvelle_valeur ;
    }

    public void set_protection( int protection ) {
        this.protection = protection ;
    }

}