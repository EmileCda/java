
/*
    1. Reprendre l'exercice sur le personnage
    2. Découper le code en plusieurs fichiers (1 par classe)
    3. Créer un package "personnage" dans lequel se trouvera l'ensemble de nos classes sauf Main
    4. Dans le package "personnage", créer un sous-package "equipement", dans lequel on trouvera Arme et Armure
    5. Adapter le programme pour qu'il fonctionne avec cette arborescence
*/

import personnage.Personnage ;
import personnage.equipement.Arme ;
import personnage.equipement.Armure ;

public class Main {

    public static void main( String[] args ) {

        // Scénario d'un combat entre Bilbo et Golum
        Personnage bilbo = new Personnage(
            "Bilbo",
            new Arme( "Poings", 150 ),
            new Armure( "Cape", 50 )
        );
        Personnage golum = new Personnage(
            "Golum",
            new Arme( "Fléche", 80 ),
            new Armure( "Cuirasse", 100 )
        );
        
        bilbo.afficher();
        golum.afficher();

        System.out.println( golum.get_nom() ) ;

        bilbo.attaquer( golum );

        bilbo.afficher();
        golum.afficher();

        // // Scénario d'un combat entre Bilbo et 3 trolls
        Personnage[] trolls = {
            new Personnage(
                "Toto",
                new Arme( "Lance", 70 ),
                new Armure( "Pagne", 10) 
            ),
            new Personnage(
                "Gogo",
                new Arme( "Arc", 50 ),
                new Armure( "Casque", 30) 
            ),
            new Personnage(
                "Koko",
                new Arme( "Epée", 100 ),
                new Armure( "Cuirasse", 120) 
            ),
        };

        bilbo.attaquer( trolls );

        // // Et ici création de Frodon
        Personnage frodon = new Personnage( 
            "Frodon", 
            new Arme( "Epée", 100 ),
            new Armure( "Cuirasse", 120),
            110 
        );
        Personnage sam = new Personnage( frodon );
        // Personnage sam = Personnage.copy( frodon );
        Personnage pipin = frodon.copy();

        sam.set_nom( "Sam" );
        pipin.set_nom( "Pipin" );

        sam.afficher();
        pipin.afficher();

        System.out.println("Nous avons créé " + Personnage.get_nombre() + " personnages");
    }

}




